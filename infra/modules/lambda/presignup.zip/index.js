exports.handler = async (event) => {
  const allowedEmails = ["elimillera@gmail.com"];
  const email = event.request.userAttributes.email.toLowerCase();
        
  if (!allowedEmails.map(e => e.toLowerCase()).includes(email)) {
    throw new Error("Email not in the allowed list. Contact the administrator to request access.");
  }
        
  // Auto-confirm the email to simplify the sign-up flow
  event.response.autoConfirmUser = true;
  event.response.autoVerifyEmail = true;
        
  return event;
};
