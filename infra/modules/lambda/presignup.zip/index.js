exports.handler = async (event) => {
  const allowedEmails = ["elimillera@gmail.com","benstraub28@gmail.com","haesendonckx.steven@gmail.com","jeffowf@gmail.com","camilla.calmasini@gmail.com","robertdevine.smartgxp@gmail.com","dmitry.m.kolosov@gmail.com","vitalreddy.j@gmail.com","RMao6@ITS.JNJ.com","dtord@its.jnj.com","mdanbarasan@gmail.com","dtord@its.jnj.com","kirill1gorshkov@gmail.com","mftuchman@mpactmodeling.com","gen.zhu@novartis.com","allemahesh303@gmail.com","naren.kotapati@gmail.com","iaugusty@its.jnj.com","prajapatitwinkal3@gmail.com","niralikavi1997@gmail.com","adrian.waddell@posit.co"];
  const email = event.request.userAttributes.email.toLowerCase();
        
  if (!allowedEmails.map(e => e.toLowerCase()).includes(email)) {
    throw new Error("Email not in the allowed list. Contact the administrator to request access.");
  }
        
  // Auto-confirm the email to simplify the sign-up flow
  event.response.autoConfirmUser = true;
  event.response.autoVerifyEmail = true;
        
  return event;
};
